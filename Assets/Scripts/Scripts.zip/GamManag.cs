﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System;

public class GamManag : MonoBehaviour
{
	int accumulator = 0;
    int i = 0;
    float timer = 0f;
	float fps;
	
	public Text FPS;
    
    void Update() {
		i +=1;
        accumulator++;
		fps = (float)Math.Round(accumulator/Time.deltaTime, 0, MidpointRounding.AwayFromZero);
		if (i>=30)
		{
			FPS.text = "FPS: " + fps;
			i=0;
		}
		
		accumulator = 0;
    }
	/*public Text scoreH;
	public Text scoreL;
	public byte scL, scH;
    // Start is called before the first frame update
    void Start()
    {
		scH = 0;
		scL = 0;
		
        scoreH.text = "0";
		scoreL.text = "0";
    }*/

}
